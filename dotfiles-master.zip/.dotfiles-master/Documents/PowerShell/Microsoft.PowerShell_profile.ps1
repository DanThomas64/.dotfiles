# Prompt 
oh-my-posh init pwsh --config "~\scoop\apps\oh-my-posh\current\themes\robbyrussel.omp.json" | Invoke-Expression
Import-Module posh-git
Import-Module -Name Terminal-Icons

# PSReadline
Set-PSReadLineOption -PredictionSource History
Set-PSReadLineOption -PredictionViewStyle ListView
Set-PSReadLineKeyHandler -Chord 'Ctrl+k' -Function HistorySearchBackward
Set-PSReadLineKeyHandler -Chord 'Ctrl+j' -Function HistorySearchForward
Set-PSReadLineKeyHandler -Chord 'Ctrl+d' -Function RevertLine

# Variables
Set-Variable -Name 'vimrc' -Scope Local -Value $HOME\appdata\local\nvim\init.vim

# Alias
Set-Alias vim nvim
Set-Alias ll ls
Set-Alias g git
Set-Alias grep findstr


# Dotfiles
$DOTFILES = "$HOME\work\.dotfiles"

function dotfiles {
  git --git-dir="$DOTFILES" --work-tree="$HOME" @Args
}

function dotfiles-restore {
  Param ([string]$repo)
  git clone -b base --bare $repo $DOTFILES
  dotfiles config --local status.showUntrackedFiles no
  dotfiles checkout
  if ($LASTEXITCODE) {
    echo "Deal with conflicting files, then run (possibly with -f flag if you are OK with overwriting)"
    echo "dotiles checkout"
  }
}
