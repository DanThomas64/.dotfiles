Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

Install-Module oh-my-posh -Scope CurrentUser -Force

irm get.scoop.sh | iex

scoop bucket nerd-fonts
scoop bucket add main
scoop bucket extras
scoop install curl neovim sudo Cascadia-Code windows-terminal pwsh gcc z
scoop install oh-my-posh posh-git

sudo Uninstall-Module PSReadLine
sudo Install-Module -Name PSReadLine -AllowPrerelease -Scope CurrentUser -Force -SkipPublisherCheck

sudo .\scoop\buckets\nerd-fonts\bin\generate-manifests.ps1
scoop install FiraCode-NF

iwr -useb https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim |``
   ni "$(@($env:XDG_DATA_HOME, $env:LOCALAPPDATA)[$null -eq $env:XDG_DATA_HOME])/nvim-data/site/autoload/plug.vim" -Force
